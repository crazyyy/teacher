import '../../css/main.css';

export function hello() {
    console.log("hello again");
}
